exports.CatalogService = require('./srv/cat-service')
